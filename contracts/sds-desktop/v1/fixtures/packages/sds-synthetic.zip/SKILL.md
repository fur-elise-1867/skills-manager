---
name: sds-synthetic-fixture
description: Synthetic package for desktop contract tests.
---
# Fixture
Never a real Store release.
