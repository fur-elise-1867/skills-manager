---
name: jira-project-summary
description: Updated weekly reporting.
---

# Jira project summary v2

Include risks and next actions in the weekly report.
